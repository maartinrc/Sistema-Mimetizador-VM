Blameless Culture
=================

This is a work in progress. Stay tuned.

# Three Tips

- __Assume good will.__  Contributors make decisions based on what they
believe is right for the project.

- __Identify causes, not culprits.__ Accountability happens naturally as
people learn the facts.
Focus on exploring what happened—--and recognize that in complex systems,
there's rarely one root cause.

- __Take your time.__ People used to blaming cultures may take time to come
out of their shell and share mistakes and learnings freely.


# Resources

- http://www.businessinsider.com/etsy-chad-dickerson-blameless-post-mortem-2012-5
- https://codeascraft.com/2012/05/22/blameless-postmortems/
- http://www.dreamwidth.org/legal/diversity
- https://psnet.ahrq.gov/resources/resource/1582
- http://www.acm.org/about/se-code

